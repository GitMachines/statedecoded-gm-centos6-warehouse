This is the source code for the RegexHierarchyPathTokenizer.

Assuming that Maven is installed properly, you can build this code by
typing "mvn package" at the shell prompt.

One the code is built, copy it to the lib directory

    $cp target/regex-path-tokenizer-0.0.1-SNAPSHOT.jar ../lib/regex-path-tokenizer-0.0.1-SNAPSHOT.jar

Once this is done, then the reference to
RegexPathHierarchyTokenizerFactory should work.
